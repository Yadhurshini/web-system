document.addEventListener('DOMContentLoaded', function () {
    const form = document.querySelector('form');
    if (!form) {
      console.error('Form not found!');
      return;
    }
  
    form.addEventListener('submit', function (e) {
      e.preventDefault(); // Prevent form submission to allow validation
  
      const emailInput = document.querySelector('input[placeholder="Enter your email"]');
      const passwordInput = document.querySelector('input[placeholder="Enter your password"]');
  
      if (!emailInput || !passwordInput) {
        console.error('Input fields not found!');
        return;
      }
  
      const email = emailInput.value.trim();
      const password = passwordInput.value.trim();
  
      // Basic validation for empty fields
      if (!email || !password) {
        console.log('Please fill in all the fields.');
        alert('Please fill in all the fields.');
        return;
      }
  
      // Email validation
      const emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}$/;
      if (!emailPattern.test(email)) {
        console.log('Please enter a valid email address.');
        alert('Please enter a valid email address.');
        return;
      }
  
      // Password validation
      // Optionally, you can add password pattern validation here
      if (password.length < 6) {
        console.log('Password must be at least 6 characters long.');
        alert('Password must be at least 6 characters long.');
        return;
      }
  
      // If all validations pass, you can submit the form or perform other actions
      console.log('Login successful!');
      alert('Login successful!');
      form.submit(); // Submit the form if everything is correct
    });
  });