<?php
   session_start();
   include("db.php");

   if($_server['REQUEST_METHOD'] == "POST")
   {
    
    $user_name = $_POST('username');
    $E_mail = $_POST('Email');

    if(!empty($E_mail) && !empty($password) && !is_numeric($E_mail))
    {
        $query = "select * from  form where email = '$E_mail'limit 1";
        $result = mysqli_query($con, $query);

        if($result)
        {
           if($result && mysqli_num_rows($result) > 0)
           {
            $user_data = mysqli_fetch_assoc($result);
            if($user_data['Confirm password'] == $password)
            {
                echo "<script type='text/javascript'>alert('Login Successful');</script>";
              die;
            }
           }
        }
        echo"<script types='text/javascript'> alert(wrong username or password);</script>";
    }
     else{
    echo"<script types='text/javascript'> alert(wrong username or password);</script>";
    }
   }
?>





<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="login.css">
</head>
<body>
    
    <header>
        <div class="navbar">
          <label class="logo">ONLINE HEALTHCARE</label>
            </div>
        </header>
        <center>
        <section class="container form">
            <div class="form login">
            <div class="form-container">
                <h1>WELCOME BACK</h1>
                <br>
                    <p> New to Healthcare? <a href="register.php">Sign Up</a></p>

                <form action="" method="POST">
                    <div class="field input-field">
                        <input type="email" placeholder=" Enter your Email" class="input">
                    </div>

                    <div class="field input-field">
                        <input type="password" placeholder="Enter your Password" class="password">
                    </div>

                    <div class="form-link">
                        <a href="#" class="forgot-pass">forgot password?</a>
                    </div>
                    <br>
                    <div class="field button-field">
                        <button type="submit">Login</a></button>
                    </div>
                    <div class="form-link">
                        <span>Already have an account?<a href="#" class="forgot-pass">Forgot password?</a></span>
                    </div>

                </form>
            </center>
            </div>
            </div>
        </section>
        <footer>
            <center>
            <p>© Mithila Online Pharmacy, All Right Reserved</p>
        </center>
        </footer>
        <script src="login.js"></script>
</body>
</html>