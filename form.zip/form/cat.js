// Select the cart button and cart items container
const cartBtn = document.querySelector('.cart-btn');
const cartItemsContainer = document.querySelector('#cart-items');

// Create an empty cart array
let cart = [];

// Function to update the cart items container
function updateCartItems() {
  cartItemsContainer.innerHTML = '';
  cart.forEach((item) => {
    const cartItemHTML = `
      <div class="cart-item">
        <img src="${item.image}" alt="${item.name}">
        <span>${item.name}</span>
        <span>Quantity: 1</span>
        <span>Price: ${item.price}</span>
        <button class="remove-btn">Remove</button>
      </div>
    `;
    cartItemsContainer.innerHTML += cartItemHTML;
  });
}

// Add event listener to the cart button
cartBtn.addEventListener('click', () => {
  // Toggle the cart items container
  cartItemsContainer.classList.toggle('show');
});

// Add event listener to each product
document.querySelectorAll('.product').forEach((product) => {
  product.addEventListener('click', () => {
    // Get the product details
    const productName = product.querySelector('h3').textContent;
    const productPrice = product.querySelector('.price').textContent;
    const productImage = product.querySelector('img').src;

    // Add the product to the cart
    cart.push({
      name: productName,
      price: productPrice,
      image: productImage,
    });

    // Update the cart items container
    updateCartItems();
  });
});

// Add event listener to the "Remove" button
cartItemsContainer.addEventListener('click', (e) => {
  if (e.target.classList.contains('remove-btn')) {
    const removeIndex = cart.findIndex((item) => item.name === e.target.parentNode.querySelector('span').textContent);
    cart.splice(removeIndex, 1);
    updateCartItems();
  }
});