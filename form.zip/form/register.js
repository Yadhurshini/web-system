// register.js

document.addEventListener('DOMContentLoaded', function () {
    const form = document.querySelector('form');
    form.addEventListener('submit', function (e) {
        e.preventDefault(); // Prevent form submission to allow validation

        const fullName = document.querySelector('input[placeholder="Enter your name"]').value.trim();
        const userName = document.querySelector('input[placeholder="Enter your user name"]').value.trim();
        const email = document.querySelector('input[placeholder="Enter your email"]').value.trim();
        const phoneNumber = document.querySelector('input[placeholder="Enter your number"]').value.trim();
        const password = document.querySelector('input[placeholder="Enter your password"]').value.trim();
        const confirmPassword = document.querySelector('input[placeholder="confirm your password"]').value.trim();

        // Basic validation for empty fields
        if (!fullName || !userName || !email || !phoneNumber || !password || !confirmPassword) {
            alert('Please fill in all the fields.');
            return;
        }

        // Email validation
        const emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}$/;
        if (!emailPattern.test(email)) {
            alert('Please enter a valid email address.');
            return;
        }

        // Phone number validation
        const phonePattern = /^[0-9]{10}$/; // Adjust pattern based on country or format
        if (!phonePattern.test(phoneNumber)) {
            alert('Please enter a valid 10-digit phone number.');
            return;
        }

        // Password confirmation
        if (password !== confirmPassword) {
            alert('Passwords do not match.');
            return;
        }

        // If all validations pass, you can submit the form or perform other actions
        alert('Registration successful!');
        form.submit(); // Submit the form if everything is correct
    });
});
