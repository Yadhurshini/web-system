<?php
   $con = mysqli_connect("localhost", "root", "register") or die(myslq_error);
?>   
