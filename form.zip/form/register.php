<?php
   session_start();
   include("db.php");

   if($_server['REQUEST_METHOD'] == "POST")
   {
    $first_name = $_POST('full name');
    $user_name = $_POST('user name');
    $E_mail = $_POST('Email');
    $phone_no = $_POST('Phone Number');
    $password = $_POST('Password');
    $Confirmpassword = $_POST('Confirm password');
   }
  if(!empty($E_mail) && !empty($password) && !is_numeric($E_mail))
  {
    $query = "insert into form (full name, User name, Email, Phone Number, Password, Confirm password) values ('$first_name','$user_name','$E_mail','$phone_no','$password','$Confirmpassword')";

    mysqli_query($con, $query);

    echo "<script types='text/javascript'> alert(Successfully Register)</script>";
  }
  else{
    echo "<script type='text/javascript'> alert(please enter valid information)</script>";
  }

?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register and Login</title>
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.8/css/line.css">
    <link rel="stylesheet" href="register.css">

</head>
<body>
    <script src="register.js"></script>
    <header>
            <div class="navbar">
              <label class="logo">MITHILA PHARMACY</label>
                </div>
            </header>

    <div class="container">
        <center>
        <h1>Create Your Online Account</h1>
        <br>
        <p>Already you have an account?  <a href="login.php">login</a>
     </p>
    </center>
    <br>
       <form action="" method="POST">
        <div class="user-details">
            <div class="input-box">
                <span class="details">Full name</span>
                <input type="text" name="full name" placeholder="Enter your name" required>
            </div>
            <div class="input-box">
                <span class="details">User name</span>
                <input type="text" name="User name" placeholder="Enter your user name" required>
            </div>
            <div class="input-box">
                <span class="details">Email </span>
                <input type="email" name="Email" placeholder="Enter your email" required>
            </div>
            <div class="input-box">
                <span class="details">Phone Number</span>
                <input type="text"  name="phone number" placeholder="Enter your number" required>
            </div>
            <div class="input-box">
                <span class="details">Password</span>
                <input type="password" name="password" placeholder="Enter your password" required>
            </div>
            <div class="input-box">
                <span class="details">Confirm password</span>
                <input type="password" name="confirm password" placeholder="confirm your password" required>
            </div>
        </div>
        
        <div class="button">
            <button class="button">Register</button>
            <a href="login.php" class="login-link"></a>
        </div>
       </form>
    </div>
<footer>
    <center>
    <p>© Mithila Online Pharmacy, All Right Reserved</p>
</center>
</footer>
</body>
</html>