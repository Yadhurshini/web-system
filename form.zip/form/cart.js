let cart = [];

// Function to add an item to the cart
function addItemToCart(productName, quantity, price) {
    // Check if the product is already in the cart
    const existingProduct = cart.find(item => item.productName === productName);

    if (existingProduct) {
        // Update the quantity and subtotal if the product already exists in the cart
        existingProduct.quantity += quantity;
        existingProduct.subtotal = existingProduct.quantity * price;
    } else {
        // Add a new product to the cart array
        const newItem = {
            productName: productName,
            quantity: quantity,
            price: price,
            subtotal: quantity * price
        };
        cart.push(newItem);
    }
    renderCart(); // Update the cart display
}

// Function to render the cart items in the cart table
function renderCart() {
    const cartBody = document.getElementById('cart-body');
    cartBody.innerHTML = ''; // Clear the current cart contents

    let total = 0;

    // Loop through the cart items and display them
    cart.forEach((item, index) => {
        total += item.subtotal;

        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${item.productName}</td>
            <td>${item.quantity}</td>
            <td>Rs. ${item.price}</td>
            <td>Rs. ${item.subtotal}</td>
            <td><button onclick="removeItemFromCart(${index})">Remove</button></td>
        `;
        cartBody.appendChild(row); // Add the row to the cart body
    });

    // Update the total price display
    document.getElementById('total-price').textContent = `Rs. ${total}`;
}

// Function to remove an item from the cart
function removeItemFromCart(index) {
    cart.splice(index, 1); // Remove the item at the given index from the cart array
    renderCart(); // Re-render the cart to reflect the removal
}
