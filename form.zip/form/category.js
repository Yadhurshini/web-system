let cart = [];

        function addItemToCart(productName, quantity, price) {
            const existingProduct = cart.find(item => item.productName === productName);

            if (existingProduct) {
                existingProduct.quantity += quantity;
                existingProduct.subtotal = existingProduct.quantity * price;
            } else {
                const newItem = {
                    productName: productName,
                    quantity: quantity,
                    price: price,
                    subtotal: quantity * price
                };
                cart.push(newItem);
            }
            console.log(cart); // For debugging purposes
            alert(productName + " added to cart");
        }

        function addToCart(productName, price) {
            addItemToCart(productName, 1, price);
        }
